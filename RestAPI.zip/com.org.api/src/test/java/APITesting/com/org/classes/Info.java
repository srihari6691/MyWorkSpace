package APITesting.com.org.classes;

public class Info {
	
	private String EmailID;
	private String MobileNO;
	private String Address;
	
	public String getEmailID() {
		return EmailID;
	}
	public void setEmailID(String emailID) {
		this.EmailID = emailID;
	}
	public String getMobileNO() {
		return MobileNO;
	}
	public void setMobileNO(String mobileNO) {
		this.MobileNO = mobileNO;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}
	
	

}
