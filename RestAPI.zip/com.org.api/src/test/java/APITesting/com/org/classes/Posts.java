package APITesting.com.org.classes;

public class Posts {
	
	private String Id;
	private String Author;
	private String Title;

	public void setID(String id){
		this.Id=id;
	}
	public String getID(){
		return Id;
	}
	public void setTitle(String title){
		this.Title=title;
	}
	public String getTitle(){
		return Title;
	}
	public void setAuthor(String author){
		this.Author=author;
	}
	public String getAuthor(){
		return Author;
	}

}
