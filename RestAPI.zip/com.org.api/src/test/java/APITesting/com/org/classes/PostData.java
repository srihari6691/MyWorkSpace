package APITesting.com.org.classes;

public class PostData {
	
	private String ID;
	private String Name;
	private String Sex;
	private String Designation;
	private Info info;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	
	public Info getInfo(){
		return info;
	}
	public void setInfo(Info info){
		this.info = info;
	}

}
