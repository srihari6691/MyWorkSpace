package APITesting.com.org.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import static com.jayway.restassured.RestAssured.*;


public class WeatherTestGETRequest {

	//@Test
	public void test_01(){


		Response resp = when().
				get("http://samples.openweathermap.org/data/2.5/weather?lat=35&lon=139&appid=b1b15e88fa797225412429c1c50c122a1");

		System.out.println(resp.statusCode());

		Assert.assertEquals(resp.statusCode(), 200);

	}

	//@Test
	public void test_02(){


		Response resp = given().
				param("q","London").
				param("appid","b1b15e88fa797225412429c1c50c122a1").
				when().
				get("http://samples.openweathermap.org/data/2.5/weather");

		System.out.println(resp.statusCode());

		Assert.assertEquals(resp.statusCode(), 200);

	}

	//@Test
	public void test_03(){


		given().
		param("q","London").
		param("appid","b1b15e88fa797225412429c1c50c122a1").
		when().
		get("http://samples.openweathermap.org/data/2.5/weather").
		then().assertThat().statusCode(200);

	}

	//@Test
	public void test_04(){


		Response resp = given().
				param("q","London").
				param("appid","b1b15e88fa797225412429c1c50c122a1").
				when().
				get("http://samples.openweathermap.org/data/2.5/weather");

		System.out.println(resp.asString());


	}
	//@Test
	public void test_05(){


		String WeatherReport = given().
				param("id","2172797").
				param("appid","b1b15e88fa797225412429c1c50c122a1").
				when().
				get("http://samples.openweathermap.org/data/2.5/weather").
				then().contentType(ContentType.JSON).
				extract().
				path("weather[0].description");


		System.out.println(WeatherReport);


	}
	//@Test
	public void test_06(){


		Response Resp = given().
				param("id","2172797").
				param("appid","b1b15e88fa797225412429c1c50c122a1").
				when().
				get("http://samples.openweathermap.org/data/2.5/weather");

		String WeatherReport = Resp.
				then().contentType(ContentType.JSON). 
				extract().
				path("weather[0].description");
		System.out.println(WeatherReport);


	}
	@Test
	public void test_07(){

		Response Resp = given().
				parameter("id","800").
				parameter("appid","b1b15e88fa797225412429c1c50c122a1").
				when().
				get("http://samples.openweathermap.org/data/2.5/weather");

		String WeatherReportbyID = Resp.
				then().contentType(ContentType.JSON). 
				extract().
				path("weather[0].description");
		
		System.out.println(WeatherReportbyID);

		String lon = String.valueOf(Resp.
				then().contentType(ContentType.JSON).
				extract().
				path("coord.lon"));
		System.out.println("Longitude - "+lon);
		
		String lat = String.valueOf(Resp.
				then().contentType(ContentType.JSON).
				extract().
				path("coord.lat"));
		System.out.println("Longitude - "+lat);
		
		String WeatherReportByLonLat =  given().
										parameter("lat",lat).
										parameter("lon",lon).
										parameter("appid","b1b15e88fa797225412429c1c50c122a1").
										when().
										get("http://samples.openweathermap.org/data/2.5/weather").
										then().contentType(ContentType.JSON).
										extract().
										path("weather[0].description");
		
		System.out.println("WeatherReportby lon lat - "+WeatherReportByLonLat);	
		Assert.assertEquals(WeatherReportbyID, WeatherReportByLonLat);
	}

}
