package APITesting.com.org.api;

import org.testng.annotations.Test;

import APITesting.com.org.classes.Info;
import APITesting.com.org.classes.PostData;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import static com.jayway.restassured.RestAssured.*;

public class ComplexPOST {
	
	@Test
	public void complexPOST(){
		
		System.out.println("****************** New - POST request started **************************");		
		Info info = new Info();
		info.setEmailID("TestAccount@gmail.com");
		info.setMobileNO("9999999999");
		info.setAddress("INDIA");
		
		PostData postData = new PostData();
		postData.setID("1001");
		postData.setName("Srihari");
		postData.setSex("Male");
		postData.setDesignation("Analyst");
		postData.setInfo(info);
		
		Response Resp = given().
						when().
						body(postData).
						contentType(ContentType.JSON).
						post("http://localhost:3000/posts");
		
		
		System.out.println("Response: "+Resp.asString());
		
	}

	@Test(priority=10)
	public void getRequest01(){
		
		System.out.println("****************** New - Get request started **************************");
		
		Response resp = given().
						when().
						get("http://localhost:3000/comments");
		
		System.out.println(resp.asString());
				
		
	}
	
	
}
