package APITesting.com.org.api;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

import APITesting.com.org.classes.Posts;

import static com.jayway.restassured.RestAssured.*;

import org.testng.annotations.Test;

public class RequestPOST {
	
	//Not recommended
	//@Test
	public void postRequest02(){
		
		System.out.println("****************** New - Post request started **************************");
		
		Response resp = given().
						body("  {  \"id\": 3,\"title\": \"FirstPost-Request\",\"author\": \"Srihari\"  }  ").
						when().
						contentType(ContentType.JSON).
						post("http://localhost:3000/posts");
		
		System.out.println(resp.asString());			
		
	}	
	//@Test
	public void postRequest03(){
		
		System.out.println("****************** New - Post request started **************************");
		
		Posts posts = new Posts();
		posts.setID("7");
		posts.setTitle("Post Using - Post Objects");
		posts.setAuthor("Srihari Nalabolu");
		
		Response resp = given(). 
						body(posts).
						when().
						contentType(ContentType.JSON).
						post("http://localhost:3000/posts");
		
		System.out.println(resp.asString());
	
	}
	//@Test(priority=1)
	public void putRequest(){
		
		System.out.println("****************** New - Put request started **************************");
		
		Posts posts = new Posts();
		posts.setID("rygMSqs5b");
		posts.setTitle("Put Updates - Using Objects-1");
		//posts.setAuthor("Srihari1 - Updated - with PUT");
		
		Response resp = given(). 
						body(posts).
						when().
						contentType(ContentType.JSON).
						put("http://localhost:3000/posts/rygMSqs5b");
		
		System.out.println(resp.asString());
	
	}
	@Test(priority=2)
	public void patchRequest(){
		
		System.out.println("****************** New - patch request started **************************");
		
		Posts posts = new Posts();
		posts.setID("7");
		posts.setTitle("Patch Updates - Using Objects");
		posts.setAuthor("Srihari1 - Updated - With Patch");
		
		Response resp = given(). 
						body(posts).
						when().
						contentType(ContentType.JSON).
						patch("http://localhost:3000/posts/7");
		
		System.out.println(resp.asString());
	}
	@Test(priority=4)
	public void deleteRequest01(){
		
		System.out.println("****************** New - Delete request started **************************");
		
		Response resp = given().
						when().
						delete("http://localhost:3000/posts/7");
		
		System.out.println(resp.asString());
				
		
	}
	@Test(priority=10)
	public void getRequest01(){
		
		System.out.println("****************** New - Get request started **************************");
		
		Response resp = given().
						when().
						get("http://localhost:3000/posts");
		
		System.out.println(resp.asString());
				
		
	}
	

}
